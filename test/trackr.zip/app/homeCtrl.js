app.controller('homeCtrl', function ($scope, $route, $rootScope, $routeParams, $location, $http, $filter, $window, $timeout, NgMap) {
  $scope.parcels = [];
  $rootScope.spinner.on();
  $scope.parseFloat = parseFloat;

  $scope.reloadData = function () {
    $scope.getData(false);
  };

  $scope.getData = function(hideMarker){

    $http.get('data.json',{cache: false}).then(function(data){
      $scope.status = data.status;
      $scope.parcels = data.data.parcels;
      $rootScope.totalParcels = $scope.parcels.length;

      if(hideMarker) $scope.mParcel = $scope.parcels[0];
      $scope.map = "";
      NgMap.getMap().then(function(map) {
        $scope.map = map;
        if(hideMarker) $scope.map.customMarkers.infoWin.setVisible(false);
        $scope.showCustomMarker= function(evt, parcel) {
          parcel.fDate = $filter('date')(parcel.date * 1000, "MMM dd, yyyy");
          parcel.fPrice = $filter('currency')($filter('removeCommas')(parcel.price), "", 2);
          $scope.mParcel = parcel;
          $scope.map.customMarkers.infoWin.setPosition(this.getPosition());
          $scope.map.customMarkers.infoWin.setVisible(true);
        };
        $scope.closeCustomMarker= function(evt) {
          $scope.map.customMarkers.infoWin.setVisible(false);
        };
      });

      if(hideMarker)
        $scope.selectedParcel = "-1";

      $scope.displayDetails = function(parcel, index){
        $scope.selectedParcel = index;
        parcel.fDate = $filter('date')(parcel.date * 1000, "MMM dd, yyyy");
        parcel.fPrice = $filter('currency')($filter('removeCommas')(parcel.price), "", 2);
        $scope.mParcel = parcel;
        
        $scope.map.setZoom(11);
        $scope.map.customMarkers.infoWin.setPosition({pos:[parcel.live_location.latitude, parcel.live_location.longitude]});
        $scope.map.customMarkers.infoWin.setVisible(true);
        $scope.map.panTo({"lat":parcel.live_location.latitude, "lng":parcel.live_location.longitude});
        $rootScope.showMenu = !$rootScope.showMenu
      }

      $scope.propertyName = null;
      $scope.reverse = true;

      $scope.sortBy = function(propertyName) {
        $scope.reverse = ($scope.propertyName === propertyName) ? !$scope.reverse : false;
        $scope.propertyName = propertyName;
      };

      $scope.pageSize = 10;
      $scope.currentPage = 1;

      $scope.pageChanged = function(new_page) {
        $scope.currentPage = new_page;
      };

      $scope.setItemsPerPage = function(num) {
        $scope.itemsPerPage = num;
        $scope.currentPage = 1;
      }

      $scope.vpHeight = $window.innerHeight;

      function calcDimension() {
        $scope.$apply(function() {
            $scope.vpHeight = $window.innerHeight;
        });
      }

      window.onresize = calcDimension;

      if(!hideMarker){
        // console.log($('.listing li.active').trigger('click'));//.trigger('click');
        // var currentButton = angular.element(document.getElementsByClassName('.listing li.active'));
        // var currentButton = $('.listing li.active');
        $timeout(function () {
          $scope.displayDetails($scope.parcels[$scope.selectedParcel], $scope.selectedParcel);
        });
      }

      $rootScope.spinner.off();

      $rootScope.showMenu = false;

    });
  };

  $scope.getData(true);

});

