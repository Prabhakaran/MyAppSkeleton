var app = angular.module('myApp', ['ngRoute', 'ngAnimate', 'overlay-spinner', 'ui.bootstrap', 'angularUtils.directives.dirPagination', 'ngMap']);

app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
    when('/', {
      title: 'Home',
      templateUrl: 'partials/home.html',
      controller: 'homeCtrl'
    })
    .otherwise({
      redirectTo: '/'
    });
  }
])
.run(function($rootScope, $location, $interval, $http, $filter) {
  $rootScope.totalParcels = 0;
  $rootScope.APIHits = "0";
  $rootScope.spinner = {
    active: false,
    on: function() {
      this.active = true;
    },
    off: function() {
      this.active = false;
    }
  };
  $rootScope.spinner.on();

  var refreshData = function() {
    $http.get('api.json').then(function(res) {
      // $rootScope.APIHits = res.data.api_hits;
      var parts = $filter('number', 0)(res.data.api_hits);
      parts = parts.split(",");
      $rootScope.APIHits = parts.length > 1 ? (Math.round(parseInt(parts.join(""), 10) / Math.pow(1000, parts.length-1)) + " " + ["K", "M", "B"][parts.length-2]) : parts[0];
    }).catch(function(res) {
         $rootScope.APIHits = '-';
    });
  };

  $interval(refreshData, 1000);

});

app.filter('split', function() {
  return function(input, splitChar, splitIndex) {
    return input.split(splitChar)[splitIndex];
  }
});

app.filter('removeCommas', function() {
  return function(input) {
    while (input.search(",") >= 0) {
        input = (input + "").replace(',', '');
    }
    return input;
  }
});

app.filter('brDateFilter', function() {
  return function(dateSTR) {
    var o = dateSTR.replace(/-/g, "/"); // Replaces hyphens with slashes
    // console.log(Date.parse(o + " -0000"));
    return Date.parse(o + " -0000"); // No TZ subtraction on this sample
  }
});

/**
 * Truncate Filter
 * @Param text
 * @Param length, default is 10
 * @Param end, default is "..."
 * @return string
 */
app.filter('truncate', function() {
  return function(text, length, end) {
    if (isNaN(length))
      length = 10;
    if (end === undefined)
      end = "...";
    if (text.length <= length || text.length - end.length <= length)
      return text;
    else
      return String(text).substring(0, length - end.length) + end;
  };
});

app.filter('highlight', function($sce) {
  return function(text, phrase) {
    if (phrase) text = text.replace(new RegExp('('+phrase+')', 'gi'),
      '<span class="highlighted">$1</span>')

    return $sce.trustAsHtml(text)
  }
});

app.filter('domain', function () {
  return function ( input ) {
    var matches,
        output = "",
        urls = /\w+:\/\/([\w|\.]+)/;

    matches = urls.exec( input );

    if ( matches !== null ) output = matches[1];

    return output;
  };
});
