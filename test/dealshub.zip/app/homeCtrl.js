app.controller('homeCtrl', function ($scope, $rootScope, $routeParams, $location, $http, $filter) {
  $scope.deals = [];
  $rootScope.spinner.on();
  $scope.parseFloat = parseFloat;

  $rootScope.selectedView = 'list';
  $rootScope.setView = function(view) {
      $scope.selectedView = view;
  }

  $rootScope.isSelected = function(view) {
      return $scope.selectedView === view;
  }

  $rootScope.show_filter = false;
  $rootScope.toggleFilter = function() {
      $rootScope.show_filter = $scope.show_filter === false ? true: false;
  };

  $http.get('data.json').then(function(data){
    $scope.status = data.status;
    $scope.deals = data.data.deals;

    angular.forEach($scope.deals, function(value, key){
      p = value.actual_price - (value.actual_price * parseFloat(value.discount) / 100);
      $scope.deals[key].price = p;
    });

    // Filter By Provider
    $rootScope.filterDeal = {};
    $rootScope.filterByProvider = function(deal) {
      return $rootScope.filterDeal[deal.provider] || noFilter($rootScope.filterDeal);
    };

    $rootScope.getProviders = function() {
      return ($scope.deals || []).
        map(function (deal) { return deal.provider; }).
        filter(function (prov, idx, arr) { return arr.indexOf(prov) === idx; });
    };

    function noFilter(filterObj) {
      return Object.
        keys(filterObj).
        every(function (key) { return !filterObj[key]; });
    }

    $scope.propertyName = null;
    $scope.reverse = true;

    $scope.sortBy = function(propertyName) {
      $scope.reverse = ($scope.propertyName === propertyName) ? !$scope.reverse : false;
      $scope.propertyName = propertyName;
    };

    $scope.pageSize = 5;
    $scope.currentPage = 1;

    $scope.pageChanged = function(new_page) {
      $scope.currentPage = new_page;
    };

    $scope.setItemsPerPage = function(num) {
      $scope.itemsPerPage = num;
      $scope.currentPage = 1;
    }

    $rootScope.spinner.off();

  });
});


var uniqueItems = function(data, key) {
  var result = new Array();
  for (var i = 0; i < data.length; i++) {
    var value = data[i][key];

    if (result.indexOf(value) == -1) {
      result.push(value);
    }
  }
  return result;
};


app.filter('groupBy', function() {
  return function(collection, key) {
    if (collection === null) return;
    return uniqueItems(collection, key);
  };
});


app.directive('starRating', function () {
    return {
        restrict: 'A',
        template: '<ul class="rating">' +
            '<li ng-repeat="star in stars" ng-class="star">' +
            '\u2605' +
            '</li>' +
            '</ul>',
        scope: {
            ratingValue: '=',
            max: '=',
            onRatingSelected: '&'
        },
        link: function (scope, elem, attrs) {

            var updateStars = function () {
                scope.stars = [];
                for (var i = 0; i < scope.max; i++) {
                    scope.stars.push({
                        filled: i < scope.ratingValue
                    });
                }
            };

            scope.$watch('ratingValue', function (oldVal, newVal) {
                if (newVal) {
                    updateStars();
                }
            });
        }
    }
});