var app = angular.module('myApp', ['ngRoute', 'ngAnimate', 'overlay-spinner', 'ui.bootstrap', 'angularUtils.directives.dirPagination']);

app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
    when('/', {
      title: 'Home',
      templateUrl: 'partials/home.html',
      controller: 'homeCtrl'
    })
    .otherwise({
      redirectTo: '/'
    });
  }
])
.run(function($rootScope, $location) {

  /*$rootScope.$on("$routeChangeStart", function(event, next, current) {
    $rootScope.spinner.on();
  });

  $rootScope.$on('$viewContentLoaded', function(){
    $rootScope.spinner.off();
  });*/

  $rootScope.spinner = {
    active: false,
    on: function() {
      this.active = true;
    },
    off: function() {
      this.active = false;
    }
  };

  $rootScope.spinner.on();

  $rootScope.backToTop = function() {
    $('html, body').animate({ scrollTop: 0 }, 800);
  };

  var offset = 500;
  var duration = 500;
  $(window).scroll(function() {
    if ($(this).scrollTop() > offset) {
      $('.back-to-top').fadeIn(400);
    } else {
      $('.back-to-top').fadeOut(400);
    }
  });

});

app.filter('split', function() {
  return function(input, splitChar, splitIndex) {
    return input.split(splitChar)[splitIndex];
  }
});

app.filter('brDateFilter', function() {
  return function(dateSTR) {
    var o = dateSTR.replace(/-/g, "/"); // Replaces hyphens with slashes
    // console.log(Date.parse(o + " -0000"));
    return Date.parse(o + " -0000"); // No TZ subtraction on this sample
  }
});

/**
 * Truncate Filter
 * @Param text
 * @Param length, default is 10
 * @Param end, default is "..."
 * @return string
 */
app.filter('truncate', function() {
  return function(text, length, end) {
    if (isNaN(length))
      length = 10;
    if (end === undefined)
      end = "...";
    if (text.length <= length || text.length - end.length <= length)
      return text;
    else
      return String(text).substring(0, length - end.length) + end;
  };
});

app.filter('highlight', function($sce) {
  return function(text, phrase) {
    if (phrase) text = text.replace(new RegExp('('+phrase+')', 'gi'),
      '<span class="highlighted">$1</span>')

    return $sce.trustAsHtml(text)
  }
});

app.filter('domain', function () {
  return function ( input ) {
    var matches,
        output = "",
        urls = /\w+:\/\/([\w|\.]+)/;

    matches = urls.exec( input );

    if ( matches !== null ) output = matches[1];

    return output;
  };
});
