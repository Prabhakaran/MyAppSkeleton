;(function (window) {
  var angular = window.angular;

  /** TEMPLATE /template/overlay-spinner/overlay-spinner.html
   *  <div class="overlay-spinner-content">
   *    <div class="overlay-spinner-container">
   *      <div class="overlay-spinner"></div>
   *    </div>
   *    <ng-transclude></ng-transclude>
   *  </div>
   */

  // constants
  var TEMPLATE_PATH = '/template/overlay-spinner/overlay-spinner.html';
  var TEMPLATE = '';
  TEMPLATE += '<div class="overlay-spinner-content">';
  TEMPLATE +=   '<div class="overlay-spinner-container">';
  TEMPLATE +=     '<div class="overlay-spinner"></div>';
  TEMPLATE +=   '</div>';
  TEMPLATE +=   '<ng-transclude></ng-transclude>';
  TEMPLATE += '</div>';

  // module
  angular.module('overlay-spinner', ['ngAnimate']);

  // directive
  angular.module('overlay-spinner').directive('overlaySpinner', overlaySpinner);
  overlaySpinner.$inject = ['$animate'];
  function overlaySpinner ($animate) {
    return {
      templateUrl: TEMPLATE_PATH,
      scope: {active: '='},
      transclude: true,
      restrict: 'E',
      link: link
    };

    function link (scope, iElement) {
      scope.$watch('active', statusWatcher);
      function statusWatcher (active) {
        $animate[active ? 'addClass' : 'removeClass'](iElement, 'overlay-spinner-active');
      }
    }
  }

  // template
  angular.module('overlay-spinner').run(overlaySpinnerTemplate);
  overlaySpinnerTemplate.$inject = ['$templateCache'];
  function overlaySpinnerTemplate ($templateCache) {
    $templateCache.put(TEMPLATE_PATH, TEMPLATE);
  }

}.call(this, window));

