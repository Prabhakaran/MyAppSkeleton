app.controller('homeCtrl', function ($scope, $rootScope, $routeParams, $location, $http, $filter) {
  $scope.articles = [];
  $rootScope.spinner.on();
  $http.get('http://starlord.hackerearth.com/cognizantinternal/gamesarena').then(function(data){
    $scope.articles = data;
    // delete $scope.articles.data[0];
    $scope.articles.data.splice(0, 1);// remove first item
    $scope.propertyName = 'created_at';
    $scope.reverse = true;

    $scope.sortBy = function(propertyName) {
      $scope.reverse = ($scope.propertyName === propertyName) ? !$scope.reverse : false;
      $scope.propertyName = propertyName;
    };

    $scope.selectedPlatform = '';
    $scope.setPlatform = function(platform) {
        $scope.selectedPlatform = platform;
    }

    $scope.isSelected = function(platform) {
        return $scope.selectedPlatform === platform;
    }




    $scope.pageSize = 30;
    $scope.currentPage = 1;

    $scope.pageChanged = function(new_page) {
      $scope.currentPage = new_page;
    };

    $scope.setItemsPerPage = function(num) {
      $scope.itemsPerPage = num;
      $scope.currentPage = 1; //reset to first page
    }
    $rootScope.spinner.off();

    $scope.updatePoint = function(uid){
      var d_index = $scope.articles.data.map(function(d) { return d['id']; }).indexOf(uid);
      if($scope.articles.data[d_index].liked){
        --$scope.articles.data[d_index].num_points;
        $scope.articles.data[d_index].liked = false;
      }
      else{
        ++$scope.articles.data[d_index].num_points;
        $scope.articles.data[d_index].liked = true;
      }
    }

    $scope.hideArticle = function(uid){
      var d_index = $scope.articles.data.map(function(d) { return d['id']; }).indexOf(uid);
      if(d_index >= 0){
        $scope.articles.data.splice(d_index, 1);
      }
    }



  });
});