var app = angular.module('myApp', ['ngRoute', 'ngAnimate', 'overlay-spinner', 'ui.bootstrap', 'sticky']);

app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
    when('/', {
      title: 'Home',
      templateUrl: 'partials/home.html',
      controller: 'homeCtrl'
    })
    .otherwise({
      redirectTo: '/'
    });
  }
])
.run(function($rootScope, $location) {

  /*$rootScope.$on("$routeChangeStart", function(event, next, current) {
    $rootScope.spinner.on();
  });

  $rootScope.$on('$viewContentLoaded', function(){
    $rootScope.spinner.off();
  });*/

  $rootScope.spinner = {
    active: false,
    on: function() {
      this.active = true;
    },
    off: function() {
      this.active = false;
    }
  };

  $rootScope.backToTop = function() {
    $('html, body').animate({ scrollTop: 0 }, 800);
  };

  var offset = 500;
  var duration = 500;
  $(window).scroll(function() {
    if ($(this).scrollTop() > offset) {
      $('.back-to-top').fadeIn(400);
    } else {
      $('.back-to-top').fadeOut(400);
    }
  });

});

app.filter('thScore', function() {
  return function(input) {
    input = parseFloat(input);
    if(input > 8) return "green";
    else if(input > 5) return "orange";
    else return "red";
  }
});

app.filter('split', function() {
  return function(input, splitChar, splitIndex) {
    return input.split(splitChar)[splitIndex];
  }
});

app.filter('brDateFilter', function() {
  return function(dateSTR) {
    var o = dateSTR.replace(/-/g, "/"); // Replaces hyphens with slashes
    // console.log(Date.parse(o + " -0000"));
    return Date.parse(o + " -0000"); // No TZ subtraction on this sample
  }
});

/**
 * Truncate Filter
 * @Param text
 * @Param length, default is 10
 * @Param end, default is "..."
 * @return string
 */
app.filter('truncate', function() {
  return function(text, length, end) {
    if (isNaN(length))
      length = 10;
    if (end === undefined)
      end = "...";
    if (text.length <= length || text.length - end.length <= length)
      return text;
    else
      return String(text).substring(0, length - end.length) + end;
  };
});

app.filter('highlight', function($sce) {
  return function(text, phrase) {
    if (phrase) text = text.replace(new RegExp('('+phrase+')', 'gi'),
      '<span class="highlighted">$1</span>')

    return $sce.trustAsHtml(text)
  }
});


app.filter('domain', function () {
  return function ( input ) {
    var matches,
        output = "",
        urls = /\w+:\/\/([\w|\.]+)/;

    matches = urls.exec( input );

    if ( matches !== null ) output = matches[1];

    return output;
  };
});

app.directive("masonry", function () {
    var NGREPEAT_SOURCE_RE = '<!-- ngRepeat: ((.*) in ((.*?)( track by (.*))?)) -->';
    return {
        compile: function(element, attrs) {
            // auto add animation to brick element
            var animation = attrs.ngAnimate || "'masonry'";
            var $brick = element.children();
            $brick.attr("ng-animate", animation);
            
            // generate item selector (exclude leaving items)
            var type = $brick.prop('tagName');
            var itemSelector = type+":not([class$='-leave-active'])";
            
            return function (scope, element, attrs) {
                var options = angular.extend({
                    itemSelector: itemSelector
                }, scope.$eval(attrs.masonry));
                
                // try to infer model from ngRepeat
                if (!options.model) { 
                    var ngRepeatMatch = element.html().match(NGREPEAT_SOURCE_RE);
                    if (ngRepeatMatch) {
                        options.model = ngRepeatMatch[4];
                    }
                }
                
                // initial animation
                element.addClass('masonry');
                
                // Wait inside directives to render
                setTimeout(function () {
                    element.masonry(options);
                    
                    element.on("$destroy", function () {
                        element.masonry('destroy')
                    });
                    
                    if (options.model) {
                        scope.$apply(function() {
                            scope.$watchCollection(options.model, function (_new, _old) {
                                if(_new == _old) return;
                                
                                // Wait inside directives to render
                                setTimeout(function () {
                                    element.masonry("reload");
                                });
                            });
                        });
                    }
                });
            };
        }
    };
});